<template>
    <div class="todo-list">
        <todo-item v-bind:title="'Walk the Dog'" v-bind:descr="' Near the Zoo'"/>
        <todo-item :title="'Buy a Bread'" :descr="' Bring brown bread from shop'"/>
        <todo-item title="Learn new framework" descr="from Udemy"/>
        <todo-item :title="todoTitle" :descr="todoDescr"/>
        <!-- <todo-item v-for="x in todos" v-bind:key="x.id" :title="x.title" :descr="x.description"/> -->
         
    </div>
</template>

<script>
import TodoItem from '@/components/TodoItem'
export default {
    // props: {
    //     todos: {
    //         type: Array,
    //         required: true
    //     }
    // },
    components: {
        TodoItem
    },
    data() {
        return {
            todoTitle: 'Bring Chocolate',
            todoDescr: 'Only Cadbury Silk'
        }
     }

}
</script>
<style scoped>
  .todo-list {
    flex: 1;
  }
</style>

