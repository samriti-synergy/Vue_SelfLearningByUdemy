  
<template>
  <nav class="navbar is-white">
    <div class="container">
      <div class="navbar-menu">
        <div class="navbar-start">
          <a
            class="navbar-item is-active"
            href="#"
          >
            Newest
          </a>
          <a
            class="navbar-item"
            href="#"
          >
            In Progress
          </a>
          <a
            class="navbar-item"
            href="#"
          >
            Finished
          </a>
        </div>
      </div>
    </div>
  </nav>
</template>

<script>
  export default {}
</script>