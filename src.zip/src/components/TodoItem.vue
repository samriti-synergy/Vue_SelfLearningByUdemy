<template>
<div>
    <div class="todo-item">
        <div class="todo-item-content">
            <div class="todo-item-content-title">
            {{title}}
            </div>
            <div class="todo-item-content-description">
            {{descr}}
            </div>
        </div>
        </div>        
     </div>   
</template>
<script>
export default {
    //props: ['title','descr']
    //Another way to define props

    props: {
        title: {
            type: String,
            required: true
        },
        descr: {
            type: String,
            required: true
        }
    }
}
</script>

<style lang="scss" scoped>
.todo{
    &-item{
    background-color: gray;
    min-height: 70px;
    margin: 10px;
    padding: 10px;
    color: white;
    border-radius: 5px;
    font-size: 23px;

    &-content{
      &-title{
        font-weight: bold;
      }
      &-description{
        font-size: 19px;
      }
    }
  }
}

</style>